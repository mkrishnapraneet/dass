import os
# os.remove("what.txt")
os.remove("../output.txt")